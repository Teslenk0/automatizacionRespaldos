<?php
include("sarrepo_fns.php");
session_start();
if(!isset($_SESSION["myusername"])){
header("location:index.php");
}
?>
<html>
  <head>
<!DOCTYPE html>
<link href="css/bluesky.css" rel="stylesheet" type="text/css">
<link type="text/css" href="css/js/jqr/css/start/jquery-ui-1.8.12.custom.css" rel="Stylesheet" />
<link type="text/css" href="css/js/jtree/jquery.treeview.css" rel="Stylesheet" />
<link type="text/css" href="css/js/jtree/demo/screen.css" rel="Stylesheet" />
    <title>SARGRAPH-Graphical front-end for sar </title>
    <meta content="text/html; charset=unicode" http-equiv="Content-Type"/>
<script src="css/js/sorttable.js"></script>
<script src="css/js/prototype.js" Language="JavaScript" type="text/javascript"></script>
<script src="css/js/jqr/jquery-1.6.min.js"></script>
<script type="text/javascript" src="css/js/jqr/js/jquery-ui-1.8.12.custom.min.js"></script>
<SCRIPT LANGUAGE="Javascript" SRC="Code/FusionCharts/FusionCharts.js"></SCRIPT>
<script type="text/javascript">
        jQuery.noConflict();
        var $j = jQuery;
    </script>
<script src="css/js/jtree/jquery.treeview.js"></script>
<param name="WMode" value="Transparent">
<script>
        $j(function() {
                $j( "#accordion" ).accordion({
                        collapsible: true
                });
$j( "#accordion1" ).accordion({
                        collapsible: true
                });

        });
        </script>


<script>
        $j(function() {
                var dates = $j( "#date1, #date2" ).datepicker({
                        dateFormat: 'yy-mm-dd',
                        changeMonth: true,
                        changeYear: true,
                        defaultDate: "+1w",
                        changeMonth: true,
                        numberOfMonths: 1,
                        onSelect: function( selectedDate ) {
                                var option = this.id == "date1" ? "minDate" : "maxDate",
                                        instance = $j( this ).data( "datepicker" ),
                                        date = $j.datepicker.parseDate(
                                                instance.settings.dateFormat ||
                                                $j.datepicker._defaults.dateFormat,
                                                selectedDate, instance.settings );
                                dates.not( this ).datepicker( "option", option, date );
                        }
                });
        });
        </script>

<script>
        $j(function() {
                $j( "button, input:submit, a", ".demo").button();
                $j( "a", ".demo" ).click(function() { return false; });
        });
        </script>

<script>
        $j.fx.speeds._default = 1000;
        $j(function() {
                $j( "#dialog" ).dialog({
                        autoOpen: false,
                        show: "blind",
                        hide: "explode"
                });

                $j( "#opener" ).click(function() {
                        $j( "#dialog" ).dialog( "open" );
                        return false;
                });
        });
        </script>

<script>
        $j(function() {
                $j( "#accordion" ).accordion({
                        collapsible: true
                });
        });
        </script>

<script>
function announce()
{
var myAjax = new Ajax.PeriodicalUpdater({success: 'ace'}, 'announce.php', {method: 'post', frequency: 30.0, decay: 1});
}
</script>

  </head>
  <body onload="announce()">
       <div id="header" style="background-image: url(images/filler.JPG); HEIGHT: 50px"><img src="images/sargraph1.PNG" width=200 height=50></div>
      <div class=mnu style="HEIGHT: 11px"><a href="home.php">Home</a> &nbsp; <a href="about.php">About</a> &nbsp; <a href="index.php?logout=1">Logout</a> &nbsp; <a href=http://sargraph.com/index.php?option=com_content&view=article&id=48&Itemid=13 target=_blank>Documentation</a> &nbsp; <a href=http://sargraph.com/index.php?option=com_content&view=article&id=47&Itemid=14 target=_blank>Updates</a></div>
