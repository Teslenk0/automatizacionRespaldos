      <div class="ft" align="center" style="background-image: url(images/filler.JPG)">
© 20101- SARGRAPH
 </div>
  </body>
</html>
