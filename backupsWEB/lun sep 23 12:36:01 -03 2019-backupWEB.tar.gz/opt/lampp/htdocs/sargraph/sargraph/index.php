<?php
include("sarrepo_fns.php");
if(isset($_GET['logout'])){
$stat="You are logged out!";
session_start();
session_destroy();
}
if(isset($_GET['login'])){
$stat="Denied! try again";
}


if(isset($_POST['Submit'])){
$myusername=$_POST['myusername'];
$mypassword=$_POST['mypassword'];

$num=userCheck("$myusername","$mypassword");
if($num==1){
session_start();
$_SESSION['myusername'] = stripslashes($myusername);
$_SESSION['mypassword'] = stripslashes($mypassword);
header("location:home.php");
}
else {
header("location:index.php?login=error");
}
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Sargraph Login</title>
<style type="text/css">
a:link { color: white; text-decoration: none }
a:visited { color: white; text-decoration: none }
a:hover { color: rgb(0, 96, 255) }
a:active { color: rgb(255, 0, 102) }

#login {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	line-height: 1px;
	text-decoration: none;
	background-color: #039;
	background-repeat: repeat;
	height: 320px;
	width: 462px;
	overflow: visible;
	position: absolute;
	visibility: visible;
	left: 25%;
	top: 25%;
	right: auto;
	bottom: auto;
	background-image: url(images/filler_new.PNG);
	color: #FFF;
	-moz-border-radius: 15px;
        border-radius: 15px;

}
.login-form {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
	font-style: normal;
	font-weight: bold;
	font-variant: normal;
	text-transform: none;
	color: #FFF;
	text-decoration: none;
}
#copyright1 {
	font-family: Verdana, Geneva, sans-serif;
	font-size: 12px;
	font-style: normal;
	font-weight: normal;
	color: #FFF;
	font-variant: small-caps;
}
</style>
</head>

<body bgcolor="#CCCCCC">
<div id="login">
  <table width="100%" height="317" border="0" cellpadding="0" cellspacing="0">
    <caption>&nbsp;
    </caption>
    <tr>
      <td width="100%" height="57"><p><img src="images/sargraph1.PNG" alt="" width="235" height="56" align="left" /></p></td>
    </tr>
    <tr>
      <td height="178" align="center" valign="middle"><form id="form1" name="form1" method="post" action="index.php">
        <br><p>Login: <?php echo $stat; ?></p>
        <p>Username: 
          <input type="text" name="myusername" id="myusername" />
        </p>
        <p>Password:
          <input name="mypassword" type="password" id="mypassword" />
        </p>
	<p>
	<input type="submit" name="Submit" id="Submit" value="Login" />
	</p>
      </form></td>
    </tr>
    <tr>
<td height="100" align="center"><br><p id="copyright1"> © 2011 <a href="http://www.sargraph.com" title="Sargraph" target="_new" >Sargraph.com</a></p></td>
   </tr>
  </table>
</div>
</div>
</body>
</html>
