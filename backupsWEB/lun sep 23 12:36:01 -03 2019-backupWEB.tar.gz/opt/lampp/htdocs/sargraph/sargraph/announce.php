<?php
$out=file_get_contents('http://sargraph.com/announcement.php');
echo $out;
?>
