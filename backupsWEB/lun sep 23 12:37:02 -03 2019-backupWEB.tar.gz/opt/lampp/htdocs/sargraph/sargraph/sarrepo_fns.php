<?php
function userCheck($username,$password){
$password=exec("echo $username$password|md5sum|cut -b 1-8",$result);
$cnt=0;
$handle = @fopen("etc/users.conf", "r");
if ($handle){
while (!feof($handle)) {
$buffer = fgetcsv($handle, 4096, ":");
if ($buffer[0] == $username) {
if ($buffer[1] == $password) {
$cnt=$cnt+1;
return $cnt;
}
}
}
}
fclose($handle);
}

function srvparam($server,$param){
$handle = @fopen("etc/servers.conf", "r");
if ($handle){
while (!feof($handle)) {
$buffer = fgetcsv($handle, 4096, ":");
if ($buffer[0] == $server || $buffer[0] == "#$server")
{
if ($param == memtotal){
$val=$buffer[3];
}
if ($param == swaptotal){
$val=$buffer[4];
}
if ($param == os){
$val=$buffer[1];
}
if ($param == tz){
$val=$buffer[6];
}
}
}
}
fclose($handle);
return $val;
}


function dateCount($date1,$date2) {
$d1=$date1;
$d2=$date2;
$datecnt=0;
while ($d1<=$d2){
$datecnt=$datecnt+1;
$d1=strftime("%Y-%m-%d", strtotime("$d1 +1 day"));
}
return $datecnt;
}

function repoRead($server,$date1,$date2,$datecnt,$byaver,$type) {

while ($date1<=$date2) {

$handle = @fopen("wdir/daily/$server$date1.$type", "r");
if ($handle) {
    while (!feof($handle)) {
        $buffer = fgetcsv($handle, 4096, ",");
$n=count($buffer);
$i=0;
while ($i<$n){
if ($buffer[$i] != NULL){
if ($buffer[$i] != "Average:"){
$rdata[$i][] = $buffer[$i];
}
}
$i++;
}
if ($byaver == 1)
{
$n = count($rdata[0]);
$out[] = round(array_sum($rdata[1])/$n,2); 
$label[] = $date1;
}
    }
}
    fclose($handle);
$date1=strftime("%Y-%m-%d", strtotime("$date1 +1 day"));
}
if ($byaver == 1)
{
return array($label,$out);
}
else 
{
return array($rdata[0],$rdata[1]);
}

}
?>
