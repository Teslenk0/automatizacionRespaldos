/opt/lampp/htdocs/sargraph/sargraph/scripts/updatesar.sh localhost
