<?php include("menu.php"); ?>
<div style="BACKGROUND-COLOR: #eeeeee; WIDTH: 110%; HEIGHT: 94%">
<div style="WIDTH: 50%">
<h1 class=head>About SARGRAPH</h1><br>
<hr>
<p class=black> Sargraph is a Graphicial front-end tool for SAR (system Activity report)<br>Version: 3.1<br>
Build date: 30-Jan-2016<br>
For help and updates please visit <a href="http://sargraph.com" target="_blank">sargraph</a></p><br>
</div>
</div>
<?php include("footer.php"); ?>
