<div style="BACKGROUND-COLOR: #E0DFDE; WIDTH: 95%; HEIGHT=30px">
<div id="accordion">
<h3><a href="#">Select date and graph styles</a></h3>
<div>
<div align=right style="BACKGROUND-COLOR: #ffffff;HEIGHT=3px"><input type="image" src="images/help.png" width="20" height="20" id="opener" ></div>

<form action="" method="post">
<?php
echo "<label for='from'>From&nbsp;</label>";
echo "<input type='text' id='date1' name='date1' value='$date1'>";
echo "<label for='to'>&nbsp;to&nbsp;</label><input type='text' id='date2' name='date2' value='$date2'>";
//echo "<input type=hidden name=server value='$server'>";
echo "<label>&nbsp;Chart Type:</label>";
echo "&nbsp;";
echo "<select name=chart value=$chart>";
$handle = @fopen("etc/chartypes", "r");
if ($handle){
while (!feof($handle)) {
$buffer = fgetcsv($handle, 4096, ",");
if ($buffer[0] != NULL){
if ($buffer[0]==$chart){
echo "<option value=$buffer[0] SELECTED>$buffer[1]</option>";
}
else {
echo "<option value=$buffer[0]>$buffer[1]</option>";
}
}
}
}
fclose($handle);
echo "</select>";

echo "&nbsp;";
echo "&nbsp;";
echo "Size:";
echo "&nbsp;";
echo "<select name=chartwd value=$chartwd>";
$handle = @fopen("etc/chartwidth", "r");
if ($handle){
while (!feof($handle)) {
$buffer = fgetcsv($handle, 4096, ",");
if ($buffer[0] != NULL){
if ($buffer[0]==$chartwd){
echo "<option value=$buffer[0] SELECTED>$buffer[1]</option>";
}
else {
echo "<option value=$buffer[0]>$buffer[1]</option>";
}
}
}
}
fclose($handle);
echo "</select>";
echo "<input type=hidden name=server value='$server'>";
echo "&nbsp;";
echo "&nbsp;";
echo "&nbsp;";
echo "<hr>";

if ( $byaver ==1 ) {
echo "<br><input type=checkbox name=average value=1 CHECKED>Graph by Daily Average";
}
else {
echo "<br><input type=checkbox name=average value=1>Graph by Daily Average";
}
?>
&nbsp;

<label class="demo"><input type="submit" name="Submit" value="Submit" />
</label>
</form>

</div></div></div>
