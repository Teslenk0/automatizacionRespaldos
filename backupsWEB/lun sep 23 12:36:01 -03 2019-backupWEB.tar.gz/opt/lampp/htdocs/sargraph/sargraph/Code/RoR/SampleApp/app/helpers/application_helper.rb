# Methods added to this helper will be available to all templates in the application.
# These methods can be used to render the chart using FusionCharts
module ApplicationHelper

    require "fusioncharts_helper"
    include FusionChartsHelper

end