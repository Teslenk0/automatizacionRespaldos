<?php

$time_start = microtime(true); // Toma instante inicial

$delay_time = 3; 	// Tiempo de demora en segundos

$max_items = 800;	// Cantidad de elementos de un array

$palabra = "Sera que gasta memooria esta porqueria"; 
$tam = strlen($palabra);

echo "<html><head><title>ADI TEST</title></head>\n<body>\n";
echo "<h1>Bienvenido la aplicacion web misteriosa ...</h1>\n";

echo "La variable <b>palabra</b> tiene tam = ". $tam ." bytes<br />\n";

// Ahora se dedicar� un poco a consumir memoria
for ($j=0; $j < $max_items; $j++)
{
	$vec_palabras[$j] = $palabra;
}

$mem = $max_items * $tam;

echo "Memoria utilizada: ". $mem . " bytes<br />\n";

// En este loop va a consumir un poco de procesador
$i = 1;
while ($i <= 5120)
{
	echo ".";
	if ($i % 64 == 0)  // cada vez que $i es multiplo de 128, hace esto
	{
		echo "<br />\n";
		sleep($delay_time); // produce una demora en segundos
	}
	$i++;
}

$time_stop = microtime(true); // Toma instante final

$delta_t = $time_stop - $time_start; // Calcula variacion de tiempo

echo "<br /> Tiempo empleado en ejecuci�n: " . round($delta_t,4) ." segundos";

echo "</body></html>";

?>
