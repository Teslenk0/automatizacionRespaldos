<?php include("menu.php"); ?>
<div style="BACKGROUND-COLOR: #eeeeee; HEIGHT: 100%">
<?php 
$date=date("Y-m-d");
$sarconf='/etc/sargraph.conf';
//$ROOTDIR=$_SERVER['DOCUMENT_ROOT'];
$ROOTDIR=exec("pwd");
if (file_exists($sarconf)) {
$i=0;
$lin=0;
$sun=0;
$handle = @fopen("etc/servers.conf", "r");
if ($handle){
while (!feof($handle)) {
$buffer = fgetcsv($handle, 4096, ":");
if ($buffer[0] != NULL){
$i=$i+1;
if ($buffer[1] == Linux)
{
$lin=$lin+1;
}
else if ($buffer[1] == SunOS)
{
$sun=$sun+1;
}
}
}
}
echo "<br>";
?>
<div id='ace' style="WIDTH: 80%; MARGIN-LEFT: 50px"></div>
<div style="BACKGROUND-COLOR: #eeeeee;WIDTH: 20%; MARGIN-LEFT: 50px" >

<div id="accordion" >
	<h3><a href="#">At a Glance</a></h3>
<?php

echo "<ul><li>Active Servers:  $i </li><li>Linux Hosts: $lin </li><li>Solaris Hosts: $sun</li></ul></div></div>";
?>
<div style="BACKGROUND-COLOR: #eeeeee; WIDTH: 90%; MARGIN-LEFT: 50px" >

<div id="accordion1" >
        <h3><a href="#">Servers - Select each host to view the graphs</a></h3>

<?php
echo "<table border=0 cellpadding=1 cellspacing=1 class='sortable'><tr><th>Platform</th><th>Server</th><th width=30%>OS</th><th>Memory size(KB)</th><th>Swap Size(KB)</th><th>CPU model</th><th>Time Zone</th><th>Polling</tr>";
$i=0;
$handle = @fopen("etc/servers.conf", "r");
if ($handle){
while (!feof($handle)) {
$buffer = fgetcsv($handle, 4096, ":");
if ($buffer[0] != NULL){
$i=$i+1;
$string=$buffer[0];
if ($buffer[1] == Linux)
{
echo "<tr><th class=srv><img src=images/Linux-logo.jpg height=30 width=30></th>";
}
else if ($buffer[1] == SunOS)
{
echo "<tr><th class=srv><img src=images/solaris-logo.png height=30 width=30></th>";
}
else
{
echo "<tr><th class=srv></th>";
}
if ($string[0] == "#")
{
$srv=substr($buffer[0], 1);
echo "<th class=srv><a href=chart.php?id=$srv>$srv</a></th><th class=srv width=30%>$buffer[2]</th><th class=srv>$buffer[3]</th><th class=srv>$buffer[4]</th><th class=srv>$buffer[5]</th><th class=srv>$buffer[6]</th><th class=srv>Disabled</th></tr>";
}
else
{
echo "<th class=srv><a href=chart.php?id=$buffer[0]>$buffer[0]</a></th><th class=srv width=30%>$buffer[2]</th><th class=srv>$buffer[3]</th><th class=srv>$buffer[4]</th><th class=srv>$buffer[5]</th><th class=srv>$buffer[6]</th><th class=srv>Enabled</th></tr>";
}
}
}
}
fclose($handle);
echo "</table>";
echo "</div></div>";
if ($i == 0){
echo "<p>No servers found in database!</p><br>";
echo "<p> Please add servers using $ROOTDIR/scripts/addserver servername, please see <a href=http://www.sargraph.com/index.php?option=com_content&view=article&id=48&Itemid=13 target=_blank>documentation</a> for more details.</p>";
}
}
else {
echo "<div>";
echo "<h1 class=head>Welcome to SARGRAPH</h1><br>";
echo "<p>Note: /etc/sargraph.conf not found!</p><br>";
echo "<p class=black1>Important Instructions: <p><br>";
echo "<p><li>To start with sargraph you need to copy $ROOTDIR/etc/sargraph.conf to /etc/sargraph.conf</p><br>";
echo "<p class=cl1><li>Please set permission 755 to /etc/sargraph.conf<p><br>";
echo "<p><li>Edit /etc/sargraph.conf and update ROOTDIR as $ROOTDIR</p><br>";
echo "<p><li>Please check <a href=http://www.sargraph.com/index.php?option=com_content&view=article&id=48&Itemid=13 target=_blank>documentation</a> on adding users and servers<p><br>";
echo "</div>";

}
?>
<br>
</div>
<?php include("footer.php"); ?>
