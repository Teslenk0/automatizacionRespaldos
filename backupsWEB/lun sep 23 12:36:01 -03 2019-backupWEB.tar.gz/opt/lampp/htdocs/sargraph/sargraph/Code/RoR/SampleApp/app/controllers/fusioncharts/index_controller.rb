# This controller is used to display the list of actions 
# from different controllers in this application.
class Fusioncharts::IndexController < ApplicationController

  def index
  end
  
end
